//
// Created by Ryan on 9/30/19.
//

#include "BFS.h"

void BFS::IterBFS(int target, Graph g) {

}

void BFS::RecurBFS(int target, Graph g) {

}

void BFS::bothBFS(int target, Graph g) {
    IterBFS(target, g);
    //RecurBFS(target, g);
}