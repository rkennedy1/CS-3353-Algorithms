#ifndef MYLINKEDLIST_H
#define MYLINKEDLIST_H

#include "ListNode.h"
#include <iostream>

using namespace std;

template <typename T>
class myLinkedList
{
private:
    ListNode<T> *head;
    ListNode<T> *tail;
    ListNode<T> *myIterator;
    int numElements = 0;
public:
    myLinkedList(); //done
    myLinkedList(ListNode<T> val); //done
    ~myLinkedList(); //done
    myLinkedList(const myLinkedList<T> &old); //done
    myLinkedList<T>& operator=(const myLinkedList<T> &rhs); //done
    T& operator[](int index); //done
    void insertBack(T val);//done
    void insertFront(T val);
    void removeAt(int pos);
    void deleteBack(); //done
    void deleteFront(); //done
    int getLength(); //done
    void resetIter();   //done
    T next();    //done
    ListNode<T>& getIter();   //done
    bool nextExist(); //done
};

template <typename T>
myLinkedList<T>::myLinkedList() {
    this->head = nullptr;
    this->tail = nullptr;
    this->numElements = 0;
    this->myIterator = nullptr;
}

template <typename T>
myLinkedList<T>::myLinkedList(ListNode<T> val) {
    numElements = 0;
    head = val.next;
    tail = val.prev;
    }

template <typename T>
myLinkedList<T>::~myLinkedList() {
    if (this->head != nullptr) {
        ListNode<T> *curr = this->head; //sets curr to head
        while (curr->next != nullptr) { //loops through all items in LL
           curr = curr->next; //sets curr to next
           delete curr->prev; //deletes prev pointer
        }
        delete curr; //deletes curr
    }
}

template <typename T>
myLinkedList<T>& myLinkedList<T>::operator=(const myLinkedList<T> &rhs) {
    ListNode<T>* curr = rhs.head; //sets curr to rhs.head
    while (curr != nullptr) { //loops through all items in LL
        insertBack(curr->payload); //inserts the value of curr into the LL
        curr = curr->next; //points curr to next item
    }
    return *this;
}

template <typename T>
myLinkedList<T>::myLinkedList(const myLinkedList<T> &old) {
    ListNode<T> *curr = old.head; //sets curr to old.head
    this->head = nullptr;
    this->tail = nullptr;
    this->numElements = old.numElements; //sets numElements to old numElements
    while (curr != nullptr) { //loops through all items in old LL
        insertBack(curr->payload); //inserts value of curr into this LL
        curr = curr->next; //points curr to next item
    }
}

template <typename T>
T& myLinkedList<T>::operator[](int index) {
    ListNode<T>* temp = head; //sets temp to head
    if (index > numElements && index < 0) { //checks if within bounds
        exit(0);
    } else if (index == 0) { //checks if first term
        return temp->payload;
    } else {
        for (int i = 0; i < index; i++) { //loops till index
            temp = temp->next; //points to next item in LL
        }
    }
    return temp->payload; //returns the value at the index in LL
}

template<typename T>
void myLinkedList<T>::insertBack(T val) {
    if (this->head == nullptr) {
        this->head = new ListNode<T>(val); //head is a new Node with value val
        this->tail = head; //tail is head
    } else {
        ListNode<T> *temp = new ListNode<T>(val); //creates a new node with value val
        this->tail->next = temp; //inserts after last items
        temp->prev = tail; //sets temp->prev
        this->tail = temp; //changes tail to last item now
    }
    this->numElements++; //increments numElements
}

template <typename T>
void myLinkedList<T>::insertFront(T val) {
    if (this->head == nullptr) {
        head = new ListNode<T>(val); //head is a new Node with value val
        tail = head; //tail is head
    } else {
        ListNode<T>* temp = new ListNode<T>(val);//creates a new node with value va
        this->head->prev = temp;//inserts before first items
        temp->next = head; //sets temp.next
        head = temp; //changes head to first item now
    }
    this->numElements++;//increments numElements
}

template <typename T>
void myLinkedList<T>::deleteFront() {
    if (head->next == nullptr) {
        tail = nullptr; //deletes tail
    } else {
        head->next->prev = nullptr; //deletes the first item
    }
    head = head->next; //sets the new head
    numElements--; //decremenets numElements
}

template <typename T>
void myLinkedList<T>::deleteBack() {
    if (tail->prev == nullptr) {
        head = nullptr; //deletes head
    } else {
        tail->prev->next = nullptr;//deletes the last item
    }
    tail = tail->prev;//sets the new tail
    numElements--; //decremenets numElements
}

template <typename T>
int myLinkedList<T>::getLength() {
    return numElements; //returns the length of LL
}

template <typename T>
void myLinkedList<T>::resetIter() {
    myIterator = head; //sets iterator to head
}

template <typename T>
T myLinkedList<T>::next() {
    if (nextExist()) {
        myIterator = myIterator->next; //sets iterator to next item
        return myIterator->payload; //returns the value
    } else {
        return "end"; //if next does not exist return a stop word
    }
}

template <typename T>
bool myLinkedList<T>::nextExist() {
    if (myIterator->next == nullptr) { //checks if myIterator exists
        return false;
    } else {
        return true;
    }
}

template <typename T>
ListNode<T>& myLinkedList<T>::getIter() {
    return *myIterator; //returns iterator by reference
}

#endif // MYLINKEDLIST_H