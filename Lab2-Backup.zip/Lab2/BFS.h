//
// Created by Ryan on 9/30/19.
//

#ifndef LAB2_BFS_H
#define LAB2_BFS_H

#include "Graph.h"
#include <queue>
#include <vector>

class BFS {
private:
    void IterBFS(int target, Graph g);
    void RecurBFS(int target, Graph g);
public:
    void bothBFS(int target, Graph g);

};


#endif //LAB2_BFS_H
