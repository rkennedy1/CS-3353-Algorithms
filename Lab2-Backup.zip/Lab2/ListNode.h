#ifndef LISTNODE_H
#define LISTNODE_H
#include <iostream>


template <class T>
class ListNode {
    template <class u> friend class myLinkedList;
private:
    ListNode<T>* next;
    ListNode<T>* prev;
    T payload;
public:
    ListNode<T>();
    ListNode<T>(T payload);
    ListNode<T> operator =(ListNode<T> rhs);
    bool isEmpty();
    T getPayload();
};

template <class T>
ListNode<T>::ListNode() {
    this->next = nullptr;
    this->prev = nullptr;
}

template <class T>
ListNode<T>::ListNode(T payload) {
    this->prev = nullptr;
    this->payload = payload; //sets the payload of the node
    this->next = nullptr;
}

template <class T>
ListNode<T> ListNode<T>::operator =(ListNode<T> rhs) {
    if (rhs.payload == "end") { //if payload is end AKA LL.next is nullptr
        this->prev = nullptr;
        this->next = nullptr;
        this->payload = "end";
    } else { //normal copy
        this->prev = rhs.prev;
        this->next = rhs.next;
        this->payload = rhs.payload;
    }
}

template <class T>
bool ListNode<T>::isEmpty() {
    return payload;
}

template <class T>
T ListNode<T>::getPayload() {
    return this->payload;
}
#endif // LISTNODE_H