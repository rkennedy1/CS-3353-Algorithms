//
// Created by Ryan on 9/30/19.
//

#ifndef LAB2_GRAPH_H
#define LAB2_GRAPH_H

#include "myLinkedList.h"
#include <vector>
#include <queue>

class Graph {
private:
public:
    myLinkedList<int> *list;
    int v;
    Graph(int v);
    void addEdge(int v, int val);
    void iterBFS(int target);
};

Graph::Graph(int v) {
    this->v = v;
    this->list = new myLinkedList<int>(v);
}

void Graph::addEdge(int v, int val) {
    list[v].insertBack(val);
}

#endif //LAB2_GRAPH_H
