//
// Created by Ryan on 9/30/19.
//

#ifndef LAB2_SEARCH_H
#define LAB2_SEARCH_H


#include "Algorithm.h"
#include <string>
#include <vector>
#include <chrono>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <iomanip>


using namespace std;
class Search : public Algorithm {
public:
    Search();

    void Load(string fileName);
    void Execute();
    void Stats();
    void Select(int sortAlgo);
    void Save(string filePath);
    void Display();
    void LoadManifest(string manifestFile);
    void Configure() {}

    vector<string> fileManifest;
    int numFiles;
    string activeAlgoLabel;
    enum SortAlgo
    {
        INSERTION, BUBBLE, MERGE, LAST
    };
private:
    int *data;
    int dataSize;
    string currentFile;
    chrono::steady_clock::time_point start;
    chrono::steady_clock::time_point end;
};


#endif //LAB2_SEARCH_H
